# Sổ tay học tập & quản lý Deadline — GitHub + PythonAnywhere

Ứng dụng Flask + SQLite, truy cập bằng trình duyệt trên điện thoại và máy tính. Gồm thêm/sửa/xóa công việc, lọc, thống kê, lịch sử, hoàn tác, xuất JSON.

## Đưa mã nguồn lên GitHub
1. Tạo repository **Private**.
2. Upload **nội dung** thư mục ZIP (không upload nguyên ZIP), giữ `templates/index.html`.
3. **Không tải lên** mật khẩu, file `congviec.db`, `.env`, hoặc WSGI thật có mật khẩu.

## Cập nhật website PythonAnywhere đã chạy
Nếu ứng dụng của bạn đã hoạt động ở `/home/phamthihaiyen/so_tay_web`, không cần tạo website mới. Bạn có thể tải các file `app.py`, `templates/index.html` lên đúng thư mục cũ qua tab **Files**, thay file cũ rồi **Web > Reload**. **Giữ nguyên** file cơ sở dữ liệu `congviec.db`; không xóa thư mục cũ hoặc ghi đè dữ liệu. Sao lưu dữ liệu trước khi cập nhật.

## Cài mới bằng GitHub trên PythonAnywhere
1. Mở **Consoles > Bash**. Chạy `git clone https://github.com/USERNAME/REPOSITORY.git ~/so_tay_github` (repo Private cần xác thực GitHub; có thể upload file bằng Files thay thế).
2. Chạy `pip3 install --user -r ~/so_tay_github/requirements.txt`.
3. Mở **Web > WSGI configuration file**. Sao chép nội dung `pythonanywhere_wsgi.py` vào file WSGI thật, thay `YOUR_PYTHONANYWHERE_USERNAME` và đặt `ADMIN_PASSWORD` riêng. **Không commit file WSGI thật chứa mật khẩu lên GitHub.**
4. Chọn **Web > Reload** rồi mở URL `https://USERNAME.pythonanywhere.com`. Đăng nhập với username `admin` và mật khẩu vừa đặt.
5. Nếu gặp HTTP 500, vào **Web > Log files > Error log**.

**Lưu dữ liệu:** SQLite đặt tại `/home/USERNAME/congviec.db` (bên ngoài thư mục code), giúp không bị ghi đè khi cập nhật code. Nếu website cũ đã có dữ liệu ở `~/so_tay_web/congviec.db`, hãy sao lưu và trỏ `DB_PATH` tới file cũ, hoặc chuyển file sang vị trí mới **trước khi chạy bản mới**. Không tạo cơ sở dữ liệu rỗng rồi tưởng dữ liệu cũ đã mất.

**Lưu ý:** PythonAnywhere gói miễn phí có giới hạn và có thể cần gia hạn website định kỳ. File SQLite không phải sao lưu: hãy xuất JSON thường xuyên. Bản này chưa hỗ trợ nhập JSON để khôi phục. Dùng HTTPS, mật khẩu mạnh, không chia sẻ tài khoản. `pythonanywhere_wsgi.py` chỉ là **mẫu**, không dùng mật khẩu mẫu trong môi trường thật.

## Kiểm tra cú pháp
`python3 -m py_compile app.py`
